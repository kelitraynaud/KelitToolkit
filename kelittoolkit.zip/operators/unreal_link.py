"""Unreal Editor remote link.

Sends Python to a running Unreal Editor through the vendored remote-execution
transport (Epic's module, see dependencies/). Also hosts the permanent
'Interchange.FeatureFlags.Import.FBX=False' fix for projects that import FBX
through UE's legacy importer.

Unreal side requirement: the 'Python Editor Script Plugin' enabled with
remote execution turned on.
"""

import json
import os
import re
import shutil

import bpy


INTERCHANGE_CVAR = 'Interchange.FeatureFlags.Import.FBX'
CONNECTION_MARKER = 'KelitToolkit-OK'
PYTHON_SETTINGS_SECTION = '[/Script/PythonScriptPlugin.PythonScriptPluginSettings]'


def run_unreal_python(commands):
    """
    Run python statements in the running Unreal Editor.

    :param list commands: python statements to execute in Unreal.
    :return tuple: (success, message)
    """
    try:
        from . import ue_remote
    except Exception:
        return False, ("Add-on files incomplete (dependencies/remote_execution.py "
                       "missing): reinstall the add-on")

    try:
        output = ue_remote.run_commands(commands)
        return True, str(output or '').strip()
    except ConnectionError:
        return False, NO_EDITOR_MESSAGE
    except Exception as error:
        return False, f"Remote execution failed: {error}"


NO_EDITOR_MESSAGE = ("No running Unreal Editor found. Open your UE project and enable "
                     "'Python Editor Script Plugin' with remote execution")


def is_no_editor_error(message):
    """True when a run_unreal_python failure means 'no editor answered': the
    only case the Connection Doctor can help with. An editor that answered
    but failed the command, or a broken transport, is not a project-setup
    problem, and the Doctor would only show three green checks."""
    return str(message or '').startswith(NO_EDITOR_MESSAGE[:30])


def open_connection_doctor():
    """Open the Connection Doctor dialog (no editor answered). Returns
    False when it could not open (no window, e.g. in background mode)."""
    try:
        return 'CANCELLED' not in bpy.ops.kelit_toolkit.connection_doctor('INVOKE_DEFAULT')
    except RuntimeError as error:
        print(f"[KelitToolkit] could not open the Connection Doctor: {error}")
        return False


# ============================================================================
# INTERCHANGE FIX HELPERS
# ============================================================================

def find_default_engine_ini(project_dir):
    """
    Locate Config/DefaultEngine.ini from a UE project folder.

    Accepts the project root (folder containing the .uproject) or the Config
    folder itself. Returns (ini_path, error_message).
    """
    project_dir = bpy.path.abspath(project_dir) if project_dir else ''
    project_dir = os.path.normpath(project_dir)

    if not project_dir or not os.path.isdir(project_dir):
        return None, "Set a valid Unreal project folder first"

    # Allow pointing directly at the Config folder
    if os.path.basename(project_dir).lower() == 'config':
        project_dir = os.path.dirname(project_dir)

    uprojects = [f for f in os.listdir(project_dir) if f.lower().endswith('.uproject')]
    if not uprojects:
        return None, f"No .uproject file found in '{project_dir}'"

    return os.path.join(project_dir, 'Config', 'DefaultEngine.ini'), None


def apply_interchange_fix_to_ini(ini_path):
    """
    Ensure '[ConsoleVariables] Interchange.FeatureFlags.Import.FBX=False' is
    present in DefaultEngine.ini. Creates the file/section if missing and a
    '.bak' backup before modifying an existing file.

    :return tuple: (changed, message)
    """
    cvar_line = f'{INTERCHANGE_CVAR}=False'
    cvar_pattern = re.compile(
        r'^(\s*' + re.escape(INTERCHANGE_CVAR) + r'\s*=\s*)(\S+)\s*$',
        re.IGNORECASE | re.MULTILINE
    )
    section_pattern = re.compile(r'^\[ConsoleVariables\]\s*$', re.IGNORECASE | re.MULTILINE)

    if os.path.isfile(ini_path):
        with open(ini_path, 'r', encoding='utf-8-sig', errors='replace') as ini_file:
            content = ini_file.read()

        match = cvar_pattern.search(content)
        if match:
            if match.group(2).lower() == 'false':
                return False, "Already configured - the legacy FBX importer is permanent"
            new_content = cvar_pattern.sub(r'\g<1>False', content, count=1)
        else:
            section_match = section_pattern.search(content)
            if section_match:
                insert_at = section_match.end()
                new_content = content[:insert_at] + '\n' + cvar_line + content[insert_at:]
            else:
                new_content = content.rstrip('\n') + f'\n\n[ConsoleVariables]\n{cvar_line}\n'

        shutil.copy2(ini_path, ini_path + '.bak')
    else:
        os.makedirs(os.path.dirname(ini_path), exist_ok=True)
        new_content = f'[ConsoleVariables]\n{cvar_line}\n'

    with open(ini_path, 'w', encoding='utf-8') as ini_file:
        ini_file.write(new_content)

    return True, "DefaultEngine.ini updated (restart Unreal to take effect)"


# ============================================================================
# PROJECT SETUP (diagnosis + automatic fix)
# ============================================================================

def resolve_project_dir(project_dir):
    """Normalize the user's UE project path. Returns (dir, uproject_path,
    error_message)."""
    project_dir = bpy.path.abspath(project_dir) if project_dir else ''
    project_dir = os.path.normpath(project_dir)
    if not project_dir or not os.path.isdir(project_dir):
        return None, None, "Point 'UE Project' at the folder containing the .uproject file"
    if os.path.basename(project_dir).lower() == 'config':
        project_dir = os.path.dirname(project_dir)
    uprojects = [f for f in os.listdir(project_dir) if f.lower().endswith('.uproject')]
    if not uprojects:
        return None, None, f"No .uproject file found in '{project_dir}'"
    return project_dir, os.path.join(project_dir, uprojects[0]), None


def read_project_setup(project_dir):
    """
    Read the UE project files and report the state of everything the sync
    needs: Python plugin, USD Importer plugin, remote execution flag.

    :return tuple: (state dict, error message). state is None on error.
    """
    project_dir, uproject_path, error = resolve_project_dir(project_dir)
    if error:
        return None, error

    try:
        with open(uproject_path, 'r', encoding='utf-8-sig') as handle:
            data = json.load(handle)
    except Exception as read_error:
        return None, f"Could not read {os.path.basename(uproject_path)}: {read_error}"
    if not isinstance(data, dict):
        return None, f"{os.path.basename(uproject_path)} is not a JSON object"

    plugins = {entry.get('Name'): bool(entry.get('Enabled'))
               for entry in data.get('Plugins', []) if isinstance(entry, dict)}
    state = {
        'uproject': uproject_path,
        'ini': os.path.join(project_dir, 'Config', 'DefaultEngine.ini'),
        'python_plugin': plugins.get('PythonScriptPlugin', False),
        'usd_plugin': plugins.get('USDImporter', False),
        'remote_execution': False,
    }
    if os.path.isfile(state['ini']):
        with open(state['ini'], 'r', encoding='utf-8-sig', errors='replace') as handle:
            content = handle.read()
        state['remote_execution'] = bool(re.search(
            r'^\s*bRemoteExecution\s*=\s*True\s*$', content,
            re.IGNORECASE | re.MULTILINE))
    return state, None


def fix_project_setup(project_dir):
    """
    Write the missing settings into the project files: enable the Python and
    USD Importer plugins in the .uproject, turn remote execution on in
    DefaultEngine.ini. Backups (.bak) are created before each modified file.

    :return tuple: (list of fixed items, error message or None)
    """
    state, error = read_project_setup(project_dir)
    if error:
        return [], error

    fixed = []
    try:
        # 1) plugins in the .uproject
        if not (state['python_plugin'] and state['usd_plugin']):
            path = state['uproject']
            with open(path, 'r', encoding='utf-8-sig') as handle:
                data = json.load(handle)
            plugins = data.setdefault('Plugins', [])
            pending = []
            for name in ('PythonScriptPlugin', 'USDImporter'):
                entry = next((p for p in plugins
                              if isinstance(p, dict) and p.get('Name') == name), None)
                if entry is None:
                    plugins.append({'Name': name, 'Enabled': True})
                    pending.append(name)
                elif not entry.get('Enabled'):
                    entry['Enabled'] = True
                    pending.append(name)
            if pending:
                shutil.copy2(path, path + '.bak')
                with open(path, 'w', encoding='utf-8') as handle:
                    # ensure_ascii=False keeps accented project names readable
                    # instead of turning them into escape sequences
                    json.dump(data, handle, indent='\t', ensure_ascii=False)
                    handle.write('\n')
                # counted only once the file is really written
                fixed.extend(pending)

        # 2) remote execution in DefaultEngine.ini
        if not state['remote_execution']:
            ini_path = state['ini']
            line = 'bRemoteExecution=True'
            if os.path.isfile(ini_path):
                with open(ini_path, 'r', encoding='utf-8-sig', errors='replace') as handle:
                    content = handle.read()
                shutil.copy2(ini_path, ini_path + '.bak')
                key_pattern = re.compile(r'^\s*bRemoteExecution\s*=\s*\S+[ \t]*$',
                                         re.IGNORECASE | re.MULTILINE)
                if key_pattern.search(content):
                    content = key_pattern.sub(line, content, count=1)
                else:
                    section_pattern = re.compile(
                        re.escape(PYTHON_SETTINGS_SECTION) + r'[ \t]*$', re.MULTILINE)
                    section_match = section_pattern.search(content)
                    if section_match:
                        insert_at = section_match.end()
                        content = content[:insert_at] + '\n' + line + content[insert_at:]
                    else:
                        content = (content.rstrip('\n')
                                   + f'\n\n{PYTHON_SETTINGS_SECTION}\n{line}\n')
            else:
                os.makedirs(os.path.dirname(ini_path), exist_ok=True)
                content = f'{PYTHON_SETTINGS_SECTION}\n{line}\n'
            with open(ini_path, 'w', encoding='utf-8') as handle:
                handle.write(content)
            fixed.append('Remote Execution')
    except OSError as write_error:
        # read-only files are the norm in source-controlled UE projects
        # (Perforce): report instead of raising a traceback at the user
        target = os.path.basename(str(write_error.filename or '')) or 'the project files'
        done = f" Already fixed before the error: {', '.join(fixed)}." if fixed else ''
        return fixed, (f"Could not write {target}: {write_error.strerror or write_error}. "
                       f"Check that the file is not read-only or locked by source "
                       f"control, then retry.{done}")

    return fixed, None


# ============================================================================
# OPERATORS
# ============================================================================

class UNREAL_OT_connection_doctor(bpy.types.Operator):
    """Diagnose why the Unreal connection fails and fix the project files if
    needed: enables the Python and USD Importer plugins and turns remote
    execution on (with .bak backups). Restart Unreal after a fix"""
    bl_idname = "kelit_toolkit.connection_doctor"
    bl_label = "Unreal Connection Doctor"
    bl_options = {'REGISTER'}

    apply_fix: bpy.props.BoolProperty(
        name="Fix Project Files",
        description="Write the missing settings into the .uproject and "
                    "Config/DefaultEngine.ini (backups are created). "
                    "Restart Unreal afterwards",
        default=True
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=440)

    def _diagnose(self, context):
        key = context.scene.kelit_toolkit_settings.ue_project_dir
        cached = getattr(self, '_diag_cache', None)
        if cached is not None and cached[0] == key:
            return cached[1]
        result = read_project_setup(key)
        self._diag_cache = (key, result)
        return result

    def draw(self, context):
        layout = self.layout
        settings = context.scene.kelit_toolkit_settings

        box = layout.box()
        box.label(text="Checklist:", icon='INFO')
        box.label(text="1. Unreal Editor must be OPEN with your project loaded")
        box.label(text="2. Only ONE Unreal Editor running (the wrong one may answer)")
        box.label(text="3. Project setup below must be all green, then restart Unreal")

        layout.prop(settings, "ue_project_dir")

        state, error = self._diagnose(context)
        box = layout.box()
        if error:
            box.label(text=error, icon='ERROR')
            return

        def status_row(label, ok):
            row = box.row()
            row.label(text=label, icon='CHECKMARK' if ok else 'CANCEL')

        status_row("Python Editor Script Plugin enabled", state['python_plugin'])
        status_row("USD Importer plugin enabled", state['usd_plugin'])
        status_row("Remote execution turned on", state['remote_execution'])

        all_good = (state['python_plugin'] and state['usd_plugin']
                    and state['remote_execution'])
        if all_good:
            box.label(text="Project files look good. If it still fails,", icon='INFO')
            box.label(text="restart Unreal and check points 1 and 2.")
        else:
            layout.prop(self, "apply_fix")

    def execute(self, context):
        settings = context.scene.kelit_toolkit_settings
        state, error = read_project_setup(settings.ue_project_dir)
        if error:
            self.report({'WARNING'}, error)
            return {'CANCELLED'}

        all_good = (state['python_plugin'] and state['usd_plugin']
                    and state['remote_execution'])
        if all_good:
            self.report({'INFO'}, "Project files are correctly configured. Make sure "
                                  "Unreal is running (and restart it if settings just changed)")
            return {'FINISHED'}

        if not self.apply_fix:
            self.report({'INFO'}, "Nothing changed (Fix Project Files was unticked)")
            return {'CANCELLED'}

        fixed, fix_error = fix_project_setup(settings.ue_project_dir)
        if fix_error:
            self.report({'ERROR'}, fix_error)
            return {'CANCELLED'}
        self.report({'INFO'}, f"Fixed: {', '.join(fixed)}. Now open/restart Unreal Editor")
        return {'FINISHED'}


class UNREAL_OT_test_connection(bpy.types.Operator):
    """Check that a running Unreal Editor answers over remote execution"""
    bl_idname = "kelit_toolkit.test_connection"
    bl_label = "Test Unreal Connection"
    bl_options = {'REGISTER'}

    def execute(self, context):
        success, message = run_unreal_python([
            'import unreal',
            f"unreal.log('{CONNECTION_MARKER}')",
            f"print('{CONNECTION_MARKER}')",
        ])

        if success:
            self.report({'INFO'}, "Unreal Editor connected ✓")
            return {'FINISHED'}

        self.report({'WARNING'}, message)
        # open the doctor so the user sees WHY and can fix the project files
        # (only when no editor answered: that is what it diagnoses)
        if is_no_editor_error(message):
            bpy.ops.kelit_toolkit.connection_doctor('INVOKE_DEFAULT')
        return {'CANCELLED'}


class UNREAL_OT_fix_interchange_permanent(bpy.types.Operator):
    """Make Unreal 5.5+ use its legacy FBX importer for files imported by hand. Edits Config/DefaultEngine.ini with a backup; restart Unreal after"""
    bl_idname = "kelit_toolkit.fix_interchange_permanent"
    bl_label = "Fix Interchange FBX (Permanent)"
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        settings = context.scene.kelit_toolkit_settings
        ini_path, error = find_default_engine_ini(settings.ue_project_dir)
        if error:
            self.report({'WARNING'}, error)
            return {'CANCELLED'}

        self._ini_path = ini_path
        return context.window_manager.invoke_props_dialog(self, width=450)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="This will modify:", icon='FILE_TICK')
        box.label(text=getattr(self, '_ini_path', ''))
        box.label(text="A .bak backup will be created first.", icon='INFO')
        box.label(text="Restart Unreal Editor afterwards.", icon='INFO')

    def execute(self, context):
        settings = context.scene.kelit_toolkit_settings
        ini_path, error = find_default_engine_ini(settings.ue_project_dir)
        if error:
            self.report({'WARNING'}, error)
            return {'CANCELLED'}

        try:
            changed, message = apply_interchange_fix_to_ini(ini_path)
        except OSError as os_error:
            self.report({'ERROR'}, f"Could not write DefaultEngine.ini: {os_error}")
            return {'CANCELLED'}

        self.report({'INFO'}, message)
        return {'FINISHED'}


AUTO_PROJECT_CHOICE = ('AUTO', 'Automatic (one editor only)',
                       'Refuse to guess when multiple editors are open')

# Blender keeps only pointers to the strings a dynamic enum callback
# returns: they must stay alive for as long as the property can be drawn.
# The list object is never replaced (only its content), and every tuple
# ever handed out is also kept in _PROJECT_CHOICES_KEEPALIVE.
_PROJECT_CHOICES = [AUTO_PROJECT_CHOICE]
_PROJECT_CHOICES_KEEPALIVE = {}


def update_project_choices(nodes):
    """Refresh the Choose Project items in place from discovered editors.
    Returns the project roots found."""
    roots = []
    items = [AUTO_PROJECT_CHOICE]
    for node in nodes:
        root = str(node.get('project_root') or '')
        if not root or root in roots:
            continue
        roots.append(root)
        name = str(node.get('project_name') or root)
        items.append(_PROJECT_CHOICES_KEEPALIVE.setdefault((root, name), (root, name, root)))
    _PROJECT_CHOICES[:] = items
    return roots


def project_choice_items(_self, _context):
    return _PROJECT_CHOICES


class UNREAL_OT_choose_project(bpy.types.Operator):
    """Choose which running Unreal project receives all toolkit commands"""
    bl_idname = 'kelit_toolkit.choose_unreal_project'
    bl_label = 'Choose Unreal Project'
    destination: bpy.props.EnumProperty(name='Destination', items=project_choice_items)

    def invoke(self, context, event):
        from . import ue_remote
        try:
            nodes = ue_remote.find_editors()
        except Exception as error:
            self.report({'ERROR'}, f"Could not look for running Unreal editors: {error}. "
                                   "Check the remote-execution ports in the add-on preferences")
            return {'CANCELLED'}
        roots = update_project_choices(nodes)
        if not roots:
            self.report({'WARNING'}, "No Unreal editor answered: open your project in Unreal "
                                     "(remote execution on), then choose again")
        current = context.scene.kelit_toolkit_settings.ue_target_project
        self.destination = current if current in roots else (roots[0] if len(roots) == 1 else 'AUTO')
        return context.window_manager.invoke_props_dialog(self, width=500)

    def draw(self, context):
        self.layout.prop(self, 'destination')
        self.layout.label(text='Geometry and materials stay on this project throughout a send.')

    def execute(self, context):
        context.scene.kelit_toolkit_settings.ue_target_project = '' if self.destination == 'AUTO' else self.destination
        return {'FINISHED'}


classes = (
    UNREAL_OT_choose_project,
    UNREAL_OT_connection_doctor,
    UNREAL_OT_test_connection,
    UNREAL_OT_fix_interchange_permanent,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
